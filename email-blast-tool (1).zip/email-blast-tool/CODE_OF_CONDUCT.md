# Code of Conduct

Everyone interacting in the Email Blast Tool project’s codebases, issue trackers, and discussion forums is expected to be respectful and constructive. Harassment, hate speech, or other abusive behavior will not be tolerated. Maintainers reserve the right to moderate content and contributions that violate these principles.